#include <getopt.h>
#include <sys/time.h>
#include <cassert>
#include <limits>
#include <numeric>
#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_odeiv2.h>

using namespace std;

static struct options_t {
  options_t() : config(""), year(2010) {}

  void print_help() {
    cout << "USAGE: pairs [options]\n\n"
	 << "Options:\n"
	 << "-h --help            show this help message and exit\n"
	 << "-f --config=FILE     configure simulator from FILE.\n"
	 << "Simulation parameters:\n"
	 << "-y Y --year=Y        simulate until year Y (default: 2030)\n";
  }

  void parse_args(int argc, char **argv) {
    int c(0), index(0);
    option longopts[] = {
      {"help",   no_argument,       0, 'h'},
      {"config", required_argument, 0, 'f'},
      {"year",   required_argument, 0, 'y'},
      {0, 0, 0, 0}};
    while(c >= 0) {
      c = getopt_long(argc, argv, "hf:y:", longopts, &index);
      switch(c) {
      case 'h': print_help(); exit(0); break;
      case 'f': config = optarg; break;
      case 'y': year = strtoul(optarg, NULL, 0); break;
      default: break;
      }
    }
  }

  string config; // configuration filename

  unsigned int year; // year simulation ends

} options;


enum Sex {W=0, M=1, SEXES=2};
enum Age {BANDS=8, AGES=40};
enum Level {LEAST=0, LOW=1, MID=2, HIGH=3, LEVELS=4};
enum Index {
  XW = 0,                 // first index for compartments of single women
  XM = AGES * LEVELS,     // first index for compartments of single men
  XC = SEXES * AGES * LEVELS, // first index for compartments of couples
  COMPARTMENTS = SEXES * AGES * LEVELS + (AGES * AGES * LEVELS * LEVELS) // number of compartments
};

const int band[] = {
  0,0,0,0,0,
  1,1,1,1,1,
  2,2,2,2,2,
  3,3,3,3,3,
  4,4,4,4,4,
  5,5,5,5,5,
  6,6,6,6,6,
  7,7,7,7,7
};

struct Parameters {
  Parameters();

  // Configure model parameters. This uses the same input file format
  // as microbicide-ode/simulate --epidemic=FILE (version r1674); only
  // demographic inputs are used, epidemic inputs are ignored
  int configure(std::string const& filename);

  double init_size;

  double prop_sex[SEXES];
  double prop_age[BANDS];
  double prop_act[SEXES][LEVELS];

  double rate_grow_init;
  double rate_grow_late;
  double rate_grow_decr;

  double rate_mort[SEXES][BANDS];
  double rate_age;
  double rate_seek[SEXES][BANDS][LEVELS];
  double rate_dissolve; // partnership dissolution rate

  double assort_act; // assortativity by sexual activity level
  double assort_age; // assortativity by age
  double assort_dif; // assortativity by disparate age
};

// compartment index for single men or women
int index(int const g, int const a, int const k) {
  return AGES * (g * LEVELS + k) + a;
}

// compartment index for a couple. Woman aged wa, activity level wk;
// man aged ma, activity level mk
int index(int const wa, int const wk, int const ma, int const mk) {
  const int wi(AGES * wk + wa);
  const int mi(AGES * mk + ma);
  const int ns(AGES * LEVELS);
  const int i(XC + ns * wi + mi);
  assert(i >= 0 && i < COMPARTMENTS);
  return i;
  //  return XC + ns * wi + mi;
}

int model(double t, double const y[], double dy[], Parameters const& p);
void init(double y[], Parameters const& p);
void header(ostream &out);
void report(ostream &out, double const t, double const y[]);

int model(double t, double const y[], double dy[], void* params) {
  return model(t, y, dy, *((Parameters*)params));
}

int model(double t, double const y[], double dy[], Parameters const& p) {
  //  const double eps(std::numeric_limits<double>::denorm_min());
  const double eps(0.0);
  std::fill(dy, dy + COMPARTMENTS, 0.0);

  int wb, mb, wi, mi, i, j;

  // used to apportion new partnership formation by age band within
  // specific ages proportional to the distribution of ages within the
  // age band
  double propw, propm;

  double debut[SEXES][LEVELS];

  // indexed by women's attributes then men's attributes
  double partner[BANDS][LEVELS][BANDS][LEVELS];
  double influx, efflux;

  // BGN calculate sexual debut
  const double Nw(std::accumulate(y + XW, y + XM, 0.0));
  const double Nm(std::accumulate(y + XM, y + XC, 0.0));
  const double Nc(std::accumulate(y + XC, y + COMPARTMENTS, 0.0));
  const double N(Nw + Nm + 2.0 * Nc);
  const double grow_param[] = {2 * p.rate_grow_init - p.rate_grow_late, p.rate_grow_late, p.rate_grow_decr, 1978};
  const double rate_grow(grow_param[0] + (grow_param[1] - grow_param[0]) / (1 + exp(-grow_param[2] * (t - grow_param[3]))));
  for (int g(0); g < SEXES; ++g) {
    for (int k(0); k < LEVELS; ++k) {
      debut[g][k] = rate_grow * p.prop_sex[g] * p.prop_act[g][k] * N;
    }
  }
  // END calculate sexual debut

  // BGN calculate partnership formation rate
  double mixw, mixm, cnmw, cnmm;
  double active[SEXES][BANDS][LEVELS];
  double supply[SEXES][BANDS][LEVELS];
  double supply_age[SEXES][BANDS];  // sum over ages
  double supply_act[SEXES][LEVELS]; // sum over activity levels
  double supply_sex[] = {0.0, 0.0};

  for (int g(0); g < SEXES; ++g) {
    for (int b(0); b < BANDS; ++b) {
      std::fill(supply[g][b], supply[g][b] + LEVELS, 0.0);
      std::fill(active[g][b], active[g][b] + LEVELS, 0.0);
    }
  }

  for (int wa(0); wa < AGES; ++wa) {  
    wb = band[wa];    
    for (int wk(0); wk < LEVELS; ++wk) {
      assert(y[index(W, wa, wk)] >= 0);
      active[W][wb][wk] += y[index(W, wa, wk)];
    }
  }

  for (int ma(0); ma < AGES; ++ma) {  
    mb = band[ma];    
    for (int mk(0); mk < LEVELS; ++mk) {
      assert(y[index(M, ma, mk)] >= 0);
      active[M][mb][mk] += y[index(M, ma, mk)];
    }
  }

  for (int g(0); g < SEXES; ++g) {
    for (int b(0); b < BANDS; ++b) {
      for (int k(0); k < LEVELS; ++k) {
	supply[g][b][k] = p.rate_seek[g][b][k] * active[g][b][k];
	supply_sex[g] += supply[g][b][k];
      }
    }
  }

  for (int g(0); g < SEXES; ++g) {
    for (int b(0); b < BANDS; ++b) {
      supply_age[g][b] = 0.0;
      for (int k(0); k < LEVELS; ++k) supply_age[g][b] += supply[g][b][k];
    }
  }

  for (int g(0); g < SEXES; ++g) {
    for (int k(0); k < LEVELS; ++k) {
      supply_act[g][k] = 0.0;
      for (int b(0); b < BANDS; ++b) supply_act[g][k] += supply[g][b][k];
    }
  }

  for (int wb(0); wb < BANDS; ++wb) {
    for (int wk(0); wk < LEVELS; ++wk) {
      for (int mb(0); mb < BANDS; ++mb) {
	for (int mk(0); mk < LEVELS; ++mk) {
	  double mix_age, mix_act, mix_dif;

	  // BGN GARNETT
	  // Men
	  mix_age = (1.0 - p.assort_age) * supply_age[W][wb] / supply_sex[W] + p.assort_age * (wb == mb);
	  mix_act = (1.0 - p.assort_act) * supply[W][wb][wk] / supply_age[W][wb] + p.assort_act * (wk == mk);
	  if (wb == mb && mb > 0) {
	    mixm = (1.0 - p.assort_dif) * mix_age * mix_act;
	  } else if (mb == wb + 1) {
	    mix_dif = (1.0 - p.assort_age) * supply_age[W][wb+1] / supply_sex[W] + p.assort_age;
	    mixm = (mix_age + p.assort_dif * mix_dif) * mix_act;
	  } else {
	    mixm = mix_age * mix_act;
	  }

	  // Women
	  mix_age = (1.0 - p.assort_age) * supply_age[M][mb] / supply_sex[M] + p.assort_age * (wb == mb);
	  mix_act = (1.0 - p.assort_act) * supply[M][mb][mk] / supply_age[M][mb] + p.assort_act * (wk == mk);
	  if (wb == mb && wb + 1 < BANDS) {
	    mixw = (1.0 - p.assort_dif) * mix_age * mix_act;
	  } else if (mb == wb + 1) {
	    mix_dif = (1.0 - p.assort_age) * supply_age[M][mb-1] / supply_sex[M] + p.assort_age;
	    mixw = (mix_age + p.assort_dif * mix_dif) * mix_act;
	  } else {
	    mixw = mix_age * mix_act;
	  }
	  // END GARNETT

	  //	  // RANDOM MIXING
	  //	  mixw = supply[M][mb][mk] / (eps + supply_sex[M]);
	  //	  mixm = supply[W][wb][wk] / (eps + supply_sex[W]);

	  cnmw = supply[W][wb][wk] * mixw;
	  cnmm = supply[M][mb][mk] * mixm;

	  partner[wb][wk][mb][mk] = sqrt(cnmw * cnmm);

	  assert(!isnan(partner[wb][wk][mb][mk]));
	}
      }
    }
  }
  // END calculate partnership formation rate

  // 1. Equations for single women
  for (int wk(0); wk < LEVELS; ++wk) {
    for (int wa(0); wa < AGES; ++wa) {
      wb = band[wa];
      i = index(W, wa, wk);
      propw = y[i] / (eps + active[W][wb][wk]);

      influx = efflux = 0.0;
      for (int mk(0); mk < LEVELS; ++mk) {
	for (int ma(0); ma < AGES; ++ma) {
	  mb = band[ma];
	  j = index(wa, wk, ma, mk);
	  influx += (p.rate_dissolve + p.rate_mort[M][mb]) * y[j];
	}
	j = index(wa, wk, AGES - 1, mk);
	influx += p.rate_age * y[j]; // partner aged out
	for (int mb(0); mb < BANDS; ++mb) efflux += partner[wb][wk][mb][mk];
      }
      dy[i] = influx - (p.rate_mort[W][wb] + p.rate_age) * y[i] - propw * efflux;
    }
    // sexual debut and age-based inflows
    i = index(W, 0, wk);
    dy[i] += debut[W][wk];
    for (int wa(1); wa < AGES; ++wa) {
      dy[index(W, wa, wk)] += p.rate_age * y[index(W, wa-1, wk)];
    }
  }

  // 2. Equations for single men
  for (int mk(0); mk < LEVELS; ++mk) {
    for (int ma(0); ma < AGES; ++ma) {
      mb = band[ma];
      i = index(M, ma, mk);
      propm = y[i] / (eps + active[M][mb][mk]);

      influx = efflux = 0.0;
      for (int wk(0); wk < LEVELS; ++wk) {
	for (int wa(0); wa < AGES; ++wa) {
	  wb = band[wa];
	  j = index(wa, wk, ma, mk);
	  influx += (p.rate_dissolve + p.rate_mort[W][wb]) * y[j];
	}
	j = index(AGES - 1, wk, ma, mk);
	influx += p.rate_age * y[j]; // partner aged out
	for (int wb(0); wb < BANDS; ++wb) efflux += partner[wb][wk][mb][mk];
      }
      dy[i] = influx - (p.rate_mort[M][mb] + p.rate_age) * y[i] - propm * efflux;
    }
    // sexual debut and age-based inflows
    i = index(M, 0, mk);
    dy[i] += debut[M][mk];
    for (int ma(1); ma < AGES; ++ma) {
      dy[index(M, ma, mk)] += p.rate_age * y[index(M, ma-1, mk)];
    }
  }

  // 3. Equations for couples
  for (int wk(0); wk < LEVELS; ++wk) {
    for (int wa(0); wa < AGES; ++wa) {
      for (int mk(0); mk < LEVELS; ++mk) {
	for (int ma(0); ma < AGES; ++ma) {
	  wi = index(W, wa, wk);
	  mi = index(M, ma, mk);

	  wb = band[wa];
	  mb = band[ma];

	  propw = y[wi] / (eps + active[W][wb][wk]);
	  propm = y[mi] / (eps + active[M][mb][mk]);

	  i = index(wa, wk, ma, mk);

	  // propw and propm account for the proportion of age bands
	  // that come from ages wa and mb, respectively
	  influx = propw * propm * partner[wb][wk][mb][mk];

	  dy[i] = influx - (p.rate_mort[W][wb] + p.rate_mort[M][mb] + 2.0 * p.rate_age + p.rate_dissolve)* y[i];
	}
      }
    }
  }

  // age-based inflows for women in couples
  for (int wk(0); wk < LEVELS; ++wk) {
    for (int wa(1); wa < AGES; ++wa) {
      for (int mk(0); mk < LEVELS; ++mk) {
	for (int ma(0); ma < AGES; ++ma) {
	  dy[index(wa, wk, ma, mk)] += p.rate_age * y[index(wa-1, wk, ma, mk)];
	}
      }
    }
  }

  // age-based inflows for men in couples
  for (int wk(0); wk < LEVELS; ++wk) {
    for (int wa(0); wa < AGES; ++wa) {
      for (int mk(0); mk < LEVELS; ++mk) {
	for (int ma(1); ma < AGES; ++ma) {
	  dy[index(wa, wk, ma, mk)] += p.rate_age * y[index(wa, wk, ma-1, mk)];
	}
      }
    }
  }

  return GSL_SUCCESS;
}

int main(int argc, char** argv) {
  options.parse_args(argc, argv);

  cout << '%';
  for (int arg(0); arg < argc; ++arg) cout << ' ' << argv[arg];
  cout << '\n';

  char hostname[256];
  gethostname(hostname, 256);
  cout << "% Host: " << hostname << '\n';

  timeval st0, st1, ut0, ut1;
  Parameters parameters;
  int status;

  if (options.config.size() > 0) {
    status = parameters.configure(options.config);
    if (status < 0) {
      cerr << "Error: could not read configuration file (code=" << status << ")\n";
      return -1;
    } else {
      cout << "% Configuration: " << options.config << '\n';
    }
  } else {
    cout << "% Default configuration used\n";
  }

  const unsigned int init_year(1978);
  const unsigned int n(COMPARTMENTS);
  const unsigned int years(options.year - init_year);
  double t(init_year), y[n];
  const double hstart(0.0001); // initial step size

  std::fill(y, y + n, 0.0);
  init(y, parameters);

  //   double dy[n], dz[n];
  //   model(t, y, dy, parameters);
  //   //  for (int i(0); i < n; ++i) cout << i << ' ' << y[i] << ' ' << dy[i] << endl;
  //   const double hstart(0.001); // suggested initial step size
  //   double z[n], w[n];
  //   for (int i(0); i < n; ++i) z[i] = y[i] + hstart * dy[i];
  //   model(t, z, dz, parameters);
  //   for (int i(0); i < n; ++i) w[i] = z[i] + hstart * dz[i];  
  //   for (int i(0); i < n; ++i) cout << i << ' '
  // 				  << y[i] << ' ' << hstart * dy[i] << ' '
  // 				  << z[i] << ' ' << hstart * dz[i] << ' '
  // 				  << w[i] << '\n';
  //   exit(1);

  header(cout);
  report(cout, t, y);

  gettimeofday(&st0, NULL);
  gsl_odeiv2_system sys = {model, NULL, n, &parameters};
  gsl_odeiv2_driver* drv(gsl_odeiv2_driver_alloc_y_new(&sys, gsl_odeiv2_step_rk4, hstart, 1e-10, 1e-10));
  //  gsl_odeiv2_driver* drv(gsl_odeiv2_driver_alloc_y_new(&sys, gsl_odeiv2_step_rk4, hstart, 1e-8, 1e-8));
  for (unsigned int step(0); step < years; ++step) {
    gettimeofday(&ut0, NULL);
    status = gsl_odeiv2_driver_apply(drv, &t, t + 1, y);
    gettimeofday(&ut1, NULL);
    fprintf(stderr, "%0.0f %0.4f\n", t, 1e-6 * (ut1.tv_usec - ut0.tv_usec) + (ut1.tv_sec - ut0.tv_sec));
    if (status != GSL_SUCCESS) {
      cerr << "Warning: GSL is complaining at step " << step << ", s=" << status << '\n';
    }
    report(cout, t, y);
  }

  gsl_odeiv2_driver_free(drv);

  gettimeofday(&st1, NULL);
  printf("%% Simulation time: %0.4f\n", 1e-6 * (st1.tv_usec - st0.tv_usec) + (st1.tv_sec - st0.tv_sec));

  return 0;
}

Parameters::Parameters() {
  const double seek_sex[] = {1.0, 1.0};
  const double seek_age[][BANDS] = {
    {0.8, 1.4, 1.5, 1.2, 0.8, 0.4, 0.2, 0.1},
    {0.1, 0.8, 1.9, 2.2, 1.5, 0.7, 0.2, 0.1}};
  const double seek_act[][LEVELS] = {
    {0.33, 0.63, 1.5,  30.0},
    {0.01, 0.32, 3.9,  10.0}};

  init_size = 2050;
  prop_sex[M] = 0.5;
  prop_sex[W] = 0.5;

  rate_grow_init = 0.058;
  rate_grow_late = 0.038;
  rate_grow_decr = 0.1;

  rate_age = 1.0;

  rate_mort[W][0] = 0.00076;
  rate_mort[W][1] = 0.00129;
  rate_mort[W][2] = 0.00182;
  rate_mort[W][3] = 0.00250;
  rate_mort[W][4] = 0.00313;
  rate_mort[W][5] = 0.00444;
  rate_mort[W][6] = 0.00572;
  rate_mort[W][7] = 0.00958;

  rate_mort[M][0] = 0.00179;
  rate_mort[M][1] = 0.00370;
  rate_mort[M][2] = 0.00480;
  rate_mort[M][3] = 0.00574;
  rate_mort[M][4] = 0.00687;
  rate_mort[M][5] = 0.00930;
  rate_mort[M][6] = 0.01161;
  rate_mort[M][7] = 0.01690;

  for (int g(0); g < SEXES; ++g) {
    for (int k(0); k < LEVELS; ++k) {
      for (int b(0); b < BANDS; ++b) {
	rate_seek[g][b][k] = seek_sex[g] * seek_age[g][b] * seek_act[g][k];
      }
    }
  }

  rate_dissolve = 12.0;

  prop_age[0] = 0.19;
  prop_age[1] = 0.18;
  prop_age[2] = 0.16;
  prop_age[3] = 0.13;
  prop_age[4] = 0.11;
  prop_age[5] = 0.09;
  prop_age[6] = 0.08;
  prop_age[7] = 0.06;

  prop_act[W][LEAST] = 0.207571;
  prop_act[W][MID  ] = 0.0168311;
  prop_act[W][HIGH ] = 0.00367878;
  prop_act[W][LOW  ] = 1.0 - prop_act[W][LEAST] - prop_act[W][MID] - prop_act[W][HIGH];

  prop_act[M][LEAST] = 0.159973;
  prop_act[M][MID  ] = 0.103113;
  prop_act[M][HIGH ] = 0.0271604;
  prop_act[M][LOW  ] = 1.0 - prop_act[M][LEAST] - prop_act[M][MID] - prop_act[M][HIGH];

  assort_act = 0.4;
  assort_age = 0.3;
  assort_dif = 0.8;
}


int Parameters::configure(std::string const& filename) {
  std::ifstream in(filename.c_str());
  if (in.fail()) return -1;

  std::istream_iterator<double> start(in), end;
  std::vector<double> input(start, end);
  in.close();

  if (input.size() != 119) return -2;

  init_size = input[1];

  rate_grow_init = input[2];
  rate_grow_late = input[3];
  rate_grow_decr = input[4];

  prop_sex[M] = input[5];
  prop_sex[W] = 1.0 - input[5];

  // The user may disable aging by setting the aging rate to
  // zero. This needs to be handled as a special case, since otherwise
  // rate_age is not a number, which will propagate throughout the
  // system state.
  if (input[20] == 0.0) {
    rate_age = 0.0;
  } else {
    rate_age = 1.0 / input[20];
  }

  for (int b(0); b < BANDS; ++b) rate_mort[W][b] = input[22 + b];
  for (int b(0); b < BANDS; ++b) rate_mort[M][b] = input[30 + b];

  for (int k(0); k < LEVELS; ++k) {
    for (int b(0); b < BANDS; ++b) {
      rate_seek[W][b][k] = input[38] * input[40+b] * input[56+k];
      rate_seek[M][b][k] = input[39] * input[48+b] * input[60+k];
    }
  }

  for (int b(0); b < BANDS; ++b) prop_age[b] = input[12 + b];

  prop_act[W][LEAST] = input[6];
  prop_act[W][LOW  ] = 1 - (input[6] + input[7] + input[8]);
  prop_act[W][MID  ] = input[7];
  prop_act[W][HIGH ] = input[8];

  prop_act[M][LEAST] = input[9];
  prop_act[M][LOW  ] = 1 - (input[9] + input[10] + input[11]);
  prop_act[M][MID  ] = input[10];
  prop_act[M][HIGH ] = input[11];

  assort_act = input[102];
  assort_age = input[103];
  assort_dif = input[104];

  return 0;
}

void init(double y[], Parameters const& p) {
  const double age_dist(BANDS / static_cast<double>(AGES));
  int b;
  for (int g(0); g < SEXES; ++g) {
    for (int a(0); a < AGES; ++a) {
      b = band[a];
      for (int k(0); k < LEVELS; ++k) {
  	y[index(g, a, k)] = p.init_size * age_dist * p.prop_age[b] * p.prop_act[g][k] * p.prop_sex[g];
      }
    }
  }
}

void header(ostream &out) {
  out << "year n w m single.w single.m couples";
  for (int wb(0); wb < BANDS; ++wb) {
    for (int wk(0); wk < LEVELS; ++wk) {
      for (int mb(0); mb < BANDS; ++mb) {
	for (int mk(0); mk < LEVELS; ++mk) {
	  out << " nw" << wb << wk << 'm' << mb << mk;
	}
      }
    }
  }
  out << '\n';
}

void report(ostream &out, double const t, double const y[]) {
  const double Nw(std::accumulate(y + XW, y + XM, 0.0));
  const double Nm(std::accumulate(y + XM, y + XC, 0.0));
  const double Nc(std::accumulate(y + XC, y + COMPARTMENTS, 0.0));
  const double N(Nw + Nm + 2 * Nc);
  double C[BANDS][LEVELS][BANDS][LEVELS];

  for (int wb(0); wb < BANDS; ++wb) {
    for (int wk(0); wk < LEVELS; ++wk) {
      for (int mb(0); mb < BANDS; ++mb) {
	for (int mk(0); mk < LEVELS; ++mk) {
	  C[wb][wk][mb][mk] = 0.0;
	}
      }
    }
  }

  int i, wb, mb;
  for (int wa(0); wa < AGES; ++wa) {
    for (int wk(0); wk < LEVELS; ++wk) {
      for (int ma(0); ma < AGES; ++ma) {
	for (int mk(0); mk < LEVELS; ++mk) {
	  wb = band[wa];
	  mb = band[ma];
	  i = index(wa, wk, ma, mk);
	  C[wb][wk][mb][mk] += y[i];
	}
      }
    }
  }

  out << t << ' ' << N << ' ' << Nw + Nc << ' ' << Nm + Nc << ' ' << Nw << ' ' << Nm << ' ' << Nc;
  for (int wb(0); wb < BANDS; ++wb) {
    for (int wk(0); wk < LEVELS; ++wk) {
      for (int mb(0); mb < BANDS; ++mb) {
	for (int mk(0); mk < LEVELS; ++mk) {
	  out << ' ' << C[wb][wk][mb][mk];
	}
      }
    }
  }
  out << endl;
}
